<?php get_header(); ?>

<main>

<h1>Latest Recipes</h1>

<div class="contentbox">
<?php while(have_posts()) : the_post() ?>
    <div class="box" style="background-image: url(<?php echo get_template_directory_uri()?>/img/curry.jpg);">
         
        <div class="name">Curry</div>
        
    
    </div>
    <div class="box" style="background-image: url(<?php echo get_template_directory_uri()?>/img/butter.jpg);">
         
        <div class="name">Butter Chicken</div>
        
    
    </div>
    <div class="box" style="background-image: url(<?php echo get_template_directory_uri()?>/img/pasta.jpg);">
         
         <div class="name">Pasta Bolognese</div>
         
     
     </div>

    <?php endwhile; ?>

</div>



</main>

<?php get_footer(); ?>