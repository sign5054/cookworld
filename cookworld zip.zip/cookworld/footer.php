<?php wp_footer(); ?>

<footer>CMS assignment by Eldin and Signe</footer>

  </body>
</html>