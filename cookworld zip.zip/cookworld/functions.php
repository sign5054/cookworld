<?php
function cookworld_enqueue_style() {
    wp_enqueue_style("cookworld_style", get_stylesheet_uri());
}
add_action("wp_enqueue_scripts", "cookworld_enqueue_style");

function cookworld_register_menu(){
    register_nav_menu("time_of_day_menu","Time of day menu");
}
add_action("init","cookworld_register_menu");
?>