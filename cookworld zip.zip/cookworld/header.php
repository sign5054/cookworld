<!DOCTYPE html>
<html>
  <head>
  <link rel="stylesheet" href="https://use.typekit.net/yll0yjo.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">   
    <?php wp_head(); ?>
    <title> <?php bloginfo("name") ?> </title>
  </head>
  <body>

    <header>
        <div class="logo"><img src="<?php echo get_template_directory_uri()?>/img/logo.png" alt=""></div>
        <?php wp_nav_menu(array("theme_location"=>"time_of_day_menu")) ?>
       
    </header>