<?php get_header(); ?>

<main>
    <?php $term = get_queried_object(); ?>

<h1><?php echo $term->name; ?></h1>
<div class="contentbox">
    <?php while(have_posts()) : the_post() ?>
    <div class="box" style="background-image: url(<?php the_field('picture'); ?>);">
            
            <div class="name"><a href="<?php the_permalink()?>"><?php the_title() ?></a></div>
            
        
        </div>
    <?php endwhile; ?>
</main>


<?php get_footer(); ?>